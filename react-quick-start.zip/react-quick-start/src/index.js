import React from 'react';
import ReactDOM from 'react-dom';
import { render } from 'react-dom';
import { BrowserRouter, Route, Switch} from 'react-router-dom';
import App from './components/App';
import FirstComponent from './components/Cart';
import Notfound from './components/Notfound';

const Root = () => {
        return (
				<BrowserRouter>
				  <div>
					<Switch>
					<Route exact path='/' component={App} />
					<Route path='/first' component={FirstComponent}first />
					<Route component={Notfound} />
					</Switch>
				  </div>
				</BrowserRouter>
			)
    }

render(<Root />, document.getElementById('root'));

/*function tick() {
  const element = (
    <div>
      <h1>Hello, world!</h1>
      <h2>It is {new Date().toLocaleTimeString()}.</h2>
    </div>
  );
  ReactDOM.render(element, document.getElementById('root'));
}

setInterval(tick, 1000);
*/
//prop

/*function Welcome(props) {
  return <h1>Hello, {props.name}</h1>;
}

const element = <Welcome name="Sara"/>;

ReactDOM.render(
  element,
  document.getElementById('root')
);
*/
/*
class Mylist extends React.Component{
	constructor(){
		super();
		this.state ={
			firstname:'mukesh',
			lastname: 'singh',
			age:30
		}
	}
 
	render(){
		return(
		<ul>
		<li>{this.state.firstname}</li>
		<li>{this.state.lastname}</li>
		</ul>
		)
	}
}


ReactDOM.render(<Mylist/>,document.getElementById('root')
);
*/
/*
class Mylist extends React.Component{
	constructor(){
		super();
		this.state ={
			firstname:'mukesh',
			lastname: 'singh',
			age:30
		}
	}
 
	render(){
		return(
		<ul>
		<Myitem detail={this.state.firstname}/>
		</ul>
		)
	}
}
class Myitem extends React.Component{
	render(){
		return(
		<li>
		{this.props.detail}
		</li>
		
		)
	}
}

ReactDOM.render(<Mylist/>,document.getElementById('root')
);
*/
/*
class Mylist extends React.Component{
	constructor(){
		super();
		this.state ={
			names:['mukesh', 'singh', 'bangalore']
		}
	}
 
	render(){
		return(
		<ul>
		{
			this.state.names.map(function(name){
				return <Myitem key={name} detail={name}/>
			})
		}
		
		</ul>
		)
	}
}
class Myitem extends React.Component{
	render(){
		return(
		<li>
		{this.props.detail}
		</li>
		
		)
	}
}

ReactDOM.render(<Mylist/>,document.getElementById('root')
);
*/