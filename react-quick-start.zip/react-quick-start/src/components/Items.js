import React, {Component} from 'react';



class Items extends Component {
    render() {
        return(
            <div className="item-part">Items start from here </div>  
        );
    }
}
export default Items;