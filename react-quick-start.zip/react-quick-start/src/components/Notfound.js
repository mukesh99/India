import React, {Component} from 'react';

class Notfound extends Component{
    render(){
        return(
            <div className="notfound">This page is not found</div>
        )
    }
}
export default Notfound;